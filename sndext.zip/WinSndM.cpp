#include <cstdio>
#include <minwindef.h>
#include <synchapi.h>
#include <windows.h>
#include <wincon.h>
#include <iostream>
#include <string>

// 全局变量
HWND targetWindowHandle = NULL;

// 热键回调函数
void SendTextToTarget(const std::string& text) {
    if (targetWindowHandle != NULL) {
        // 发送文本到目标窗口
        COPYDATASTRUCT cds;
        cds.dwData = 0; 
        cds.cbData = static_cast<DWORD>(text.size() + 1); // 包括结束符
        cds.lpData = const_cast<char*>(text.c_str());
        SetForegroundWindow(targetWindowHandle);
        // 发消息
        SendMessage(targetWindowHandle, WM_SETTEXT, 0, reinterpret_cast<LPARAM>(const_cast<char*>(text.c_str())));
        std::cout << "Text sent to window handle: " << targetWindowHandle << std::endl;
    } else {
        std::cout << "No target window selected." << std::endl;
    }
}

// 主程序
int main(int argc, char* argv[]) {
    int init_ofs = 0;
    if (argc > 1) {
        init_ofs = atoi(argv[1]);
        printf("Input offset: %d byte(s)\n", init_ofs);
    }
    // 注册热键
    if (!RegisterHotKey(NULL, 1, MOD_NOREPEAT, VK_F2)) {
        std::cerr << "Failed to register hotkey!" << std::endl;
        return -1;
    }
    if (!RegisterHotKey(NULL, 2, MOD_NOREPEAT, VK_F3)) {
        std::cerr << "Failed to register hotkey!" << std::endl;
        return -1;
    }
    if (!RegisterHotKey(NULL, 3, MOD_NOREPEAT, VK_F4)) {
        std::cerr << "Failed to register hotkey!" << std::endl;
        return -1;
    }
    MSG msg;
    while (GetMessage(&msg, NULL, 0, 0)) {
        if (msg.message == WM_HOTKEY) {
            switch (msg.wParam) {
                case 1: {
                    POINT cursorPos;
                    GetCursorPos(&cursorPos);
                    targetWindowHandle = WindowFromPoint(cursorPos);
                    std::cout << "Target window handle: " << targetWindowHandle << std::endl;
                    break;
                }
                case 2: {
                    std::string textToSend = "Hello, World!"; // 要发送的文本
                    // SendTextToTarget(textToSend);
                    auto fp = fopen("E:/workspace/singlefiledbg/clangdext.txt", "r");
                    size_t total_sz = 0,
                           snt_sz = init_ofs;
                    fseek(fp, 0, SEEK_END);
                    total_sz = ftell(fp);
                    fseek(fp, snt_sz, SEEK_SET);
                    int prs = (float)snt_sz/total_sz * 100;
                    char a[8 * 1024 + 1];
                    a[8 * 1024] = 0;
                    int cnt = fread(a, 1, 8 * 1024, fp);
                    printf("Send processing: %d%%...", prs);
                    while (cnt) {
                        for (auto i = 0; i < cnt; i ++)
                            SendMessage(targetWindowHandle, WM_CHAR, a[i], 0);
                        snt_sz += cnt;
                        if ((float)snt_sz/total_sz * 100 - prs >= 5) {
                            SetForegroundWindow(targetWindowHandle);
                            Sleep(100);
                            SendMessage(targetWindowHandle, WM_KEYDOWN, VK_CONTROL, 0);
                            SendMessage(targetWindowHandle, WM_KEYDOWN, 'S', 0);
                            SendMessage(targetWindowHandle, WM_KEYUP, 'S', 0);
                            SendMessage(targetWindowHandle, WM_KEYUP, VK_CONTROL, 0);
                            prs = (float)snt_sz/total_sz * 100;
                            if(prs == 100) printf("Done.\n", prs);
                            else printf("%d%%...", prs);
                        }
                        cnt = fread(a, 1, 8 * 1024, fp);
                    }
                    fclose(fp);
                    break;
                }
                case 3:
                    goto exit_flow;
                    break;
                default:
                    break;
            }

        }
    }
exit_flow:
    // 清理
    UnregisterHotKey(NULL, 1);

    return 0;
}
