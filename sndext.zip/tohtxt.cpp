#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>

void ConvertFileToHex(const std::string& inputFilePath, const std::string& outputFilePath) {
    std::ifstream inputFile(inputFilePath, std::ios::binary);
    std::ofstream outputFile(outputFilePath);

    if (!inputFile) {
        std::cerr << "无法打开输入文件: " << inputFilePath << std::endl;
        return;
    }

    unsigned char byte;
    while (inputFile.read(reinterpret_cast<char*>(&byte), sizeof(byte))) {
        outputFile << std::setw(2) << std::setfill('0') << std::hex << static_cast<int>(byte);
    }

    inputFile.close();
    outputFile.close();
}

unsigned char hexCharToByte(char high, char low) {
    int highValue = (high >= 'a') ? (high - 'a' + 10) : (high - '0');
    int lowValue = (low >= 'a') ? (low - 'a' + 10) : (low - '0');

    return (static_cast<unsigned char>(highValue) << 4) | (static_cast<unsigned char>(lowValue));
}

void ConvertHexToFile(const std::string& inputFilePath, const std::string& outputFilePath) {
    std::ifstream inputFile(inputFilePath);
    std::ofstream outputFile(outputFilePath, std::ios::binary);

    if (!inputFile) {
        std::cerr << "无法打开输入文件: " << inputFilePath << std::endl;
        return;
    }

    std::string hexValue;
    
    while (inputFile >> std::setw(2) >> hexValue) {
        if (hexValue.length() != 2) {
            std::cerr << "无效的 hex 值: " << hexValue << std::endl;
            continue;
        }
        
        unsigned char byte = hexCharToByte(hexValue[0], hexValue[1]);
        outputFile.write(reinterpret_cast<const char*>(&byte), sizeof(byte));
    }

    inputFile.close();
    outputFile.close();
}

int main() {
    int choice;
    std::string inputFilePath;
    std::string outputFilePath;

    // std::cout << "请选择操作:\n";
    // std::cout << "1. 将文件转换为 16 进制文本\n";
    // std::cout << "2. 从 16 进制文本还原文件\n";
    // std::cin >> choice;

    // std::cout << "请输入文件路径: ";
    // std::cin >> inputFilePath;
    inputFilePath = "E:/workspace/singlefiledbg/clangdext.vsix";
    outputFilePath = "E:/workspace/singlefiledbg/clangdext.txt";
    // if (choice == 1) {
        ConvertFileToHex(inputFilePath, outputFilePath);
        std::cout << "转换完成，结果已写入 " << outputFilePath << std::endl;
    // } else if (choice == 2) {
    inputFilePath.swap(outputFilePath);
    // outputFilePath = "";
        ConvertHexToFile(inputFilePath, outputFilePath);
        std::cout << "解码完成，结果已写入 " << outputFilePath << std::endl;
    // } else {
    //     std::cout << "无效的选择!" << std::endl;
    // }

    return 0;
}